# Current version (not yet released; still in development)

## Major Features and Improvements

## Bug Fixes and Other Changes

## Breaking changes

## Deprecations

# Release 0.9.0
 * Initial release of TensorFlow Data Validation.
